--[[
   Royale High Gem farm *UwU* made by Kaid