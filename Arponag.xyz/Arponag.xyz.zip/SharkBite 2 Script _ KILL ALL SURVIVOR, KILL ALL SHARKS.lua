loadstring(game:HttpGet(('https://gist.githubusercontent.com/insuretya/13f489df942aa47cef31b3f86388d6f3/raw/cbdf238ed0c20786ac438296367ccf66a886c6da/sharkbite%2520cool.lua')))()
