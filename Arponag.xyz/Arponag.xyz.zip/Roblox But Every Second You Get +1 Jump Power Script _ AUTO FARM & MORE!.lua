while task.wait() do
game.Players.LocalPlayer.Character.Humanoid.Jump = true
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-49.6723785, 2624.06836, 27.1024342, -0.076290682, 0.061357867, -0.995195925, 9.47870227e-09, 0.998104811, 0.0615372099, 0.997085631, 0.00469470629, -0.076146096)
end