loadstring(game:HttpGet("https://raw.githubusercontent.com/Kitzoon/Roblox-Scripts/main/FIFAWorldCollectLetters.lua",true))()
