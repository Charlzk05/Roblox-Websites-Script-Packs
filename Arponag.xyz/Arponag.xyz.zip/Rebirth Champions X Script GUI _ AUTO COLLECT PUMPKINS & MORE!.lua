loadstring(game:HttpGet("https://raw.githubusercontent.com/zCurryz/Curry/main/Loader"))()
