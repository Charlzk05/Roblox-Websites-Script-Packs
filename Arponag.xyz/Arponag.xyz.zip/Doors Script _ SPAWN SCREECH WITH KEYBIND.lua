-- Keybind is H

loadstring(game:HttpGet("https://raw.githubusercontent.com/LOFICAT1/v3rm-scripts/main/Spawn%20Screech"))()