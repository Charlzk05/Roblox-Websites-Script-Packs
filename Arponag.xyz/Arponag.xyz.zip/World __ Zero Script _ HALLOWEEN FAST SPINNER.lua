while wait(.2) do
   game.ReplicatedStorage.Shared.EventSpinner.JoinQueue:FireServer(game.Players.LocalPlayer)
end