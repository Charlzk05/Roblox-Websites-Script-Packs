game:GetService("ReplicatedStorage").Remotes.TakeItem:FireServer("ITEM NAME")

-- replace ITEM NAME with Money / Banana / Coffee / Meditkit / Cheese