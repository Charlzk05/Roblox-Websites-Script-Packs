local number = 9 -- time you want your auto farm to work with

loadstring(game:HttpGet("https://pastebin.com/raw/8j0FmEW8", true))()