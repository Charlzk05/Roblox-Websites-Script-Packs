loadstring(game:HttpGet("https://raw.githubusercontent.com/Astro-Public/Astro.Public.MyResturant/main/SCRIPT", true))()
