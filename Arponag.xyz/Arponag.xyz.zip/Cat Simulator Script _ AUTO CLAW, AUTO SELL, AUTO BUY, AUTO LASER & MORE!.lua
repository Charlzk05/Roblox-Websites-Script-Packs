loadstring(game:HttpGet("https://raw.githubusercontent.com/Scharolette/Web/main/Source/CatSimulator4188447592.lua"))()
