local modulescript = require(game:GetService("Players").LocalPlayer.Backpack.Taser["ACS_Settings"])

modulescript.BulletDrop = 0