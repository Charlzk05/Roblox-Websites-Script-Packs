local origin = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.Position
local eventGarbage = game:GetService("Workspace").EventFinderReward
local pumpkins = eventGarbage.Models:GetChildren()
pumpkins = 