getgenv().toggle = true
getgenv().invis = true
loadstring(game:HttpGet("https://pastebin.com/raw/HUmWGiz0"))()