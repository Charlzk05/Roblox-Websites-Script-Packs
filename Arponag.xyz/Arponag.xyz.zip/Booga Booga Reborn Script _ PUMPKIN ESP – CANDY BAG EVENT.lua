loadstring(game:HttpGet("https://hastebin.com/raw/anajexocah",true))()
