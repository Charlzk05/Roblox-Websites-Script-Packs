loadstring(game:HttpGet("https://raw.githubusercontent.com/HeiKe2022/wz-v1.8/main/wz1.8-ArcaneMage.lua"))()
