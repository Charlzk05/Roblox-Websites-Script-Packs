loadstring(game:HttpGet("https://raw.githubusercontent.com/Gammatixx/GammaHub/main/Script"))()
