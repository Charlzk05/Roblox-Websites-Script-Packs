loadstring(game:HttpGet("https://raw.githubusercontent.com/LOLking123456/Basketball-Stars/main/2"))()
