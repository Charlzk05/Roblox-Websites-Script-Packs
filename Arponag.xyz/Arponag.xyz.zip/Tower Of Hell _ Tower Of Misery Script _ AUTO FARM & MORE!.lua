Tower Of Hell:

loadstring(game:HttpGet("https://raw.githubusercontent.com/dudeididntliterally/maintowerofhell/main/Main.lua", true))()

Tower Of Misery + Support For Difficult Mode:

loadstring(game:HttpGet("https://raw.githubusercontent.com/dudeididntliterally/towerofmiserystuff/main/code.lua", true))()