loadstring(game:HttpGet(('https://raw.githubusercontent.com/ScriptMaker69/CounterAim.cc/main/obfuscated.lua'),true))()
