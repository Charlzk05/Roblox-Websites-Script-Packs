loadstring(game:HttpGet("https://raw.githubusercontent.com/bananasp1ash/sdfefwefsfsdawf/main/README.md"))()
